function varargout = photoshop(varargin)
% PHOTOSHOP MATLAB code for photoshop.fig
%      PHOTOSHOP, by itself, creates a new PHOTOSHOP or raises the existing
%      singleton*.
%
%      H = PHOTOSHOP returns the handle to a new PHOTOSHOP or the handle to
%      the existing singleton*.
%
%      PHOTOSHOP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PHOTOSHOP.M with the given input arguments.
%
%      PHOTOSHOP('Property','Value',...) creates a new PHOTOSHOP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before photoshop_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to photoshop_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help photoshop

% Last Modified by GUIDE v2.5 07-Apr-2019 20:09:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @photoshop_OpeningFcn, ...
                   'gui_OutputFcn',  @photoshop_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before photoshop is made visible.
function photoshop_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to photoshop (see VARARGIN)

% Choose default command line output for photoshop
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes photoshop wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = photoshop_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function namafile_Callback(hObject, eventdata, handles)
% hObject    handle to namafile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of namafile as text
%        str2double(get(hObject,'String')) returns contents of namafile as a double


% --- Executes during object creation, after setting all properties.
function namafile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to namafile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cari.
function cari_Callback(hObject, eventdata, handles)
% hObject    handle to cari (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Browse file
[filename,pathname] = uigetfile('*.jpg','Pilih File');
%cek File name
if isequal ([filename,pathname],[0,0])
    return
else
    fullpath = fullfile(pathname,filename);
    handles.gui.fullpath = fullpath;
    handles.gui.filename = filename;
    handles.gui.pathname = pathname;
    %tulis nama file pada bagian edit text
    set(handles.namafile,'String',handles.gui.fullpath);
    guidata(hObject, handles);
end


% --- Executes on button press in load.
function load_Callback(hObject, eventdata, handles)
% hObject    handle to load (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% tampilkan citra addpath(handles.gui.pathname); 
addpath(handles.gui.pathname);
I = imread (handles.gui.filename);
handles.gui.I = I;
imshow(I);
guidata(hObject, handles);


% ----- BRIGHTNESS ----
function brightness_Callback(hObject, eventdata, handles) 
% hObject    handle to brightness (see GCBO) 
% eventdata  reserved - to be defined in a future version of MATLAB 
% handles    structure with handles and user data (see GUIDATA) 
% Hints: get(hObject,'Value') returns position of slider 
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider 

% get slider value 
brightness_value = get(hObject,'Value'); 
% process 
I_edit = handles.gui.I; 
bright_I(:,:,1) = uint8( bound( double(I_edit(:,:,1)) + brightness_value ) ); 
bright_I(:,:,2) = uint8( bound( double(I_edit(:,:,2)) + brightness_value ) ); 
bright_I(:,:,3) = uint8( bound( double(I_edit(:,:,3)) + brightness_value ) ); 
handles.gui.bright_I = bright_I; 
imshow(bright_I); 
guidata(hObject, handles); 


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over load.
function load_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to load (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over slider4.
function slider4_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in bright_ok.
function bright_ok_Callback(hObject, eventdata, handles)
% hObject    handle to bright_ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.brightness,'Value',0); 
handles.gui.I = handles.gui.bright_I; 
guidata(hObject, handles); 

% --- Executes on button press in contrast_ok.
function contrast_ok_Callback(hObject, eventdata, handles)
% hObject    handle to contrast_ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.contrast, 'Value',0);
handles.gui.I = handles.gui.contrast_I;
guidata(hObject, handles);

% --- Executes on slider movement.
function contrast_Callback(hObject, eventdata, handles)
% hObject    handle to contrast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%get slider value
contrast_value = get(hObject,'Value');
%proses
if contrast_value ~=0
    cv = contrast_value / 2;
    I_edit = handles.gui.I;
    contrast_I(:,:,1)= uint8(bound(round( (double(I_edit(:,:,1)) - 128) * contrast_value + 128)));
    contrast_I(:,:,2)= uint8(bound(round( (double(I_edit(:,:,2)) - 128) * contrast_value + 128)));
    contrast_I(:,:,3)= uint8(bound(round( (double(I_edit(:,:,3)) - 128) * contrast_value + 128)));
end;
handles.gui.contrast_I = contrast_I;
imshow(contrast_I);
guidata(hObject, handles);
    
% --- Executes during object creation, after setting all properties.
function contrast_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contrast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in simpan.
function simpan_Callback(hObject, eventdata, handles)
% hObject    handle to simpan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%simpan file
[FileName, PathName] = uiputfile('*.jpg', 'Save As');
if PathName == 0
    return;
end
Name = fullfile(PathName, FileName);
imwrite(handles.gui.I, Name, 'jpg');
guidata(hObject, handles);


% --- Executes on slider movement.
function slider8_Callback(hObject, eventdata, handles)
% hObject    handle to brightness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function brightness_CreateFcn(hObject, eventdata, handles)
% hObject    handle to brightness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function blur_Callback(hObject, eventdata, handles)
% hObject    handle to blur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%get slider value
blur_value = get(hObject,'Value');
%proses
handles.blur_value = round(blur_value);
BluVal = get(handle.blur,'Value');
set(handles.I,'String', handles.blur_value);
guidata(hObject, handles);
for i = 1:1000;
    position =1;
    for j = 1:800;
        if (position ==1)
            C_Red = handles.I(i,j,1);
            C_Gre = handles.I(i,j,2);
            C_Blu = handles.I(i,j,3);
        end;
    img(i,j,1) = C_Red;
    img(i,j,2) = C_Gre;
    img(i,j,3) = C_Blu;
    position = position +1;
    if(position > BluVal)
        position = 1;
    end
    end
end
handles.gui.contrast_I = contrast_I;
imshow(contrast_I);
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function blur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to blur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in blur_ok.
function blur_ok_Callback(hObject, eventdata, handles)
% hObject    handle to blur_ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rotate.
function rotate_Callback(hObject, eventdata, handles)
% hObject    handle to rotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
A= handles.gui.I;
X1= zeros([size(A,1)*size(A,2) 1]);
X2= zeros([size(A,2)*size(A,1) 1]);

deg = 90;
%change image
A = im2uint8(A)
C=uint8(zeros([size(A,1) size(A,2) 3 ]));

m=1;
%Find the midpoint
midx=ceil((size(C,1)+1)/2);
midy=ceil((size(C,2)+1)/2);

for i=1:size(A,1)
    i1=i-midx;
    for j=1:size(A,2)
        %convert from cartesian to polar
        [t,r]=cart2pol(i1,j-midy);
        %Convert from radians to degree and add the degree value
        t1=radtodeg(t)+deg;
        %Convert from degree to radians
        t=degtorad(t1);
        %Convert to Cartesian Co-ordinates
        [x,y]=pol2cart(t,r);
        x1(m)=round(x+midx);
        x2(m)=round(y+midy);
               
        m=m+1;
    end
   
end
%check whether the values are within the image size.
x1(find(x1 < 1))=1;
x2(find(x2 < 1))=1;

n=1;
for i=1:size(A,1)
    for j=1:size(A,2)
        C(x1(n),x2(n),:)=A(i,j,:);
       
        n=n+1;
    end
   
end
imshow(C);
handles.gui.I = C;
guidata(hObject, handles);




% --- Executes on button press in biner.
function biner_Callback(hObject, eventdata, handles)
% hObject    handle to biner (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_biner = handles.gui.I;
try
[rows, coloumns, numberOfColorChannel] = size(edit_biner);
if numberOfColorChannels == 3    
%convert to grayscale
    r_Channel = edit_biner(:,:,1);
    g_Channel = edit_biner(:,:,2);
    b_Channel = edit_biner(:,:,3);
    
    grayImg = .299*double(r_Channel)+...
              .587*double(g_Channel)+...
              .114*double(b_Channel);
    %convert back to uint8
    grayImg = uint8(grayImg);
else
    grayImg = edit_biner;
end
[baris, kolom] = size(grayImg);
biner = zeros(baris, kolom);
level = graythresh (grayImg)* 256;
for i = 1:baris
    for j = 1:kolom
        if grayImg(i,j) < level
            biner(i,j) = 1;
        end;
    end;
end;
%to ensure that matrix are binary type
biner = logical(biner);
imshow(biner);
handles.gui.I = biner;
guidata(hObject, handles);
end


% --- Executes on button press in median.
function median_Callback(hObject, eventdata, handles)
% hObject    handle to median (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_median = handles.gui.I;

[m n] = size(edit_median);
Med = [];

for i=2:m-1
    for j=2:n-1
        Med(1) = edit_median(i-1, j-1);
        Med(2) = edit_median(i-1, j);
        Med(3) = edit_median(i, j-1);
        Med(4) = edit_median(i+1, j);
        Med(5) = edit_median(i, j+1);
        Med(6) = edit_median(i+1, j+1);
        Med(7) = edit_median(i+1, j-1);
        Med(8) = edit_median(i-1, j+1);
        edit_median(i,j)= median(Med);
    end
end
imshow(edit_median);
handles.gui.I = edit_median;
guidata(hObject, handles);


% --- Executes on button press in grayscale.
function grayscale_Callback(hObject, eventdata, handles)
% hObject    handle to grayscale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_gray= handles.gui.I;
try
    [row,columns, numberOfColorChannels]= size(edit_gray);
    if numberOfColorChannels == 3
        %COnvert color to grey
        R_Channel = edit_gray(:, :, 1);
        G_Channel = edit_gray(:, :, 2);
        B_Channel = edit_gray(:, :, 3);
        
        grayImage = .299 * double(R_Channel) +...
                    .587 * double(G_Channel) +...
                    .114 * double(B_Channel) ;
        %convert image back to uint8, to display the image
        grayImage = unit8(grayImage);
    else
        grayImage = edit_gray;
    end
imshow(grayImage);
handles.gui.I = grayImage;
guidata(hObject, handles);
end


% --- Executes on button press in edge.
function edge_Callback(hObject, eventdata, handles)
% hObject    handle to edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_foto = handles.gui.I;

[row, col] = size(edit_foto);
if islogical(edit_foto)
    edge_foto = logical(zeros(row, col));
    Tepi = logical(zeros(8,1));
    for i = 1:row
        for j = 1:col;
          if j+1> col
            Tepi(1)=0;
          else
            Tepi(1)= edit_foto(i, j+1);
          end
          if i-1 <= 0 || j+1 > col
            Tepi(2)=0;
          else
            Tepi(2)= edit_foto(i-1, j+1);
          end
          if i-1 <= 0
            Tepi(3)=0;
          else
            Tepi(3)= edit_foto(i-1, j);
          end
          if i-1 <= 0 || j-1 <= 0
            Tepi(4)=0;
          else
            Tepi(4)= edit_foto(i-1, j-1);
          end
          if j-1 <= 0
            Tepi(5)=0;
          else
            Tepi(5)= edit_foto(i, j-1);
          end
          if i+1 > row || j-1 <= 0
            Tepi(6)=0;
          else
            Tepi(6)= edit_foto(i+1, j-1);
          end
          if i+1 > row
            Tepi(7)=0;
          else
            Tepi(7)= edit_foto(i+1, j);
          end
          if i+1 > row || j+1 > col
            Tepi(8)=0;
          else
            Tepi(8)= edit_foto(i+1, j+1);
          end

            sigma = sum(Tepi);
            if sigma == 8
                edge_foto(i,j) = 0;
            else
                edge_foto(i,j) = edit_foto(i,j);
            end
        end
    end
    handles.gui.edge_foto = edge_foto;
    handles.gui.I =handles.gui.edge_foto;
    imshow(handles.gui.I);
    guidata(hObject, handles);
else
    return;
end



% --- Executes on button press in histogram.
function histogram_Callback(hObject, eventdata, handles)
% hObject    handle to histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_histogram = handles.gui.I;

if size(edit_histogram, 3) ~= 3
    error('Input image must be RGB');
end

nBins = 256;
rHist = imhist(edit_histogram(:, :, 1), nBins);
gHist = imhist(edit_histogram(:, :, 2), nBins);
bHist = imhist(edit_histogram(:, :, 3), nBins);

h(1) = area(1:nBins, rHist, 'FaceColor', 'r'); hold on;
h(2) = area(1:nBins, gHist, 'FaceColor', 'g'); hold on;
h(3) = area(1:nBins, bHist, 'FaceColor', 'b'); hold on;

imshow(edit_histogram);
handles.gui.I = edit_histogram;
guidata(hObject, handles);


% --- Executes on button press in dilasi.
function dilasi_Callback(hObject, eventdata, handles)
% hObject    handle to dilasi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
edit_dilasi = handles.gui.I;

B=[1 1 1 1 1 1 1;];
C=padarray(edit_dilasi,[0 3]);
D=false(size(edit_dilasi));
for i=1:size(C,1)
    for j=1:size(C,2)-6
        D(i,j)=sum(B&C(i,j:j+6));
    end
end
imshow(edit_dilasi);
handles.gui.I = edit_dilasi;
guidata(hObject, handles);

